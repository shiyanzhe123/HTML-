var main = new Vue({
    el: "#main",
    data: {
        time: "",
    }
})
function tiktok() {
    var d = new Date()
    main.time = ("0" + d.getHours()).slice(-2) + ":" + ("0" + d.getMinutes()).slice(-2) + ":" + ("0" + d.getSeconds()).slice(-2) // 拼接时钟文字
}
setInterval(tiktok,1)