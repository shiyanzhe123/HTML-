var canvas = document.getElementById("canvas")
var ctx = canvas.getContext("2d")
canvas.width = 600 //设定画布尺寸
canvas.height = 600
var snake = [] //新建一个空蛇
var head = { //默认移动方向，x,y分别代表水平和垂直方向，正负1代表移动方向
    x: 0,
    y: -1
}
var egg = {} //蛋壳
function newgame() {
    snake = [] //开始新游戏，清空蛇身
    for (var i = 0; i < 5; i++) { //先给蛇5节身子
        snake.push({ //默认从10，10坐标点出发
            x: 10,
            y: 10
        })
    }
    egg = { //让蛋放置在随机的格子内
        x: parseInt(Math.random() * 20),
        y: parseInt(Math.random() * 20)
    }
}
function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height) //清屏
    ctx.fillStyle = "rgba(241, 242, 246,0.8)" //设置格子填充颜色
    for (var x = 0; x < 20; x++) { //画格子
        for (var y = 0; y < 20; y++) {
            ctx.fillRect(x * 30, y * 30, 28, 28)
        }
    }
    ctx.fillStyle = "rgba(47, 53, 66,0.8)" //设置蛇的颜色
    for (var i = 0; i < snake.length; i++) { //遍历蛇身
        body = snake[i] 
        ctx.fillRect(body.x * 30, body.y * 30, 28, 28) //画出蛇
        if (body.x == snake[0].x && body.y == snake[0].y && i != 0) { //判断蛇头是否和蛇身重合
            alert("Game Over")  //弹出提醒
            newgame() //重新开始游戏
        }
    }
    ctx.fillStyle = "rgba(55, 66, 250,0.8)" //设置蛋的颜色
    ctx.fillRect(egg.x * 30, egg.y * 30, 28, 28) //画蛋
}
function move() { //计算蛇的位置
    var newhead = {}  //定义一个新的蛇头
    switch (snake[0].x + head.x) { //判断新蛇头的位置是否超出画面范围，如超出则在反方向重新绘制（传送）
        case -1:
            newhead.x = 19
            break
        case 20:
            newhead.x = 0;
            break
        default:
            newhead.x = snake[0].x + head.x
    }
    switch (snake[0].y + head.y) {
        case -1:
            newhead.y = 19
            break
        case 20:
            newhead.y = 0
            break
        default:
            newhead.y = snake[0].y + head.y
    }
    snake.splice(0, 0, { //把新的蛇头坐标插入蛇的最前端
        x: newhead.x,
        y: newhead.y
    })
    if (snake[0].x == egg.x && snake[0].y == egg.y) { //判断蛇头是否碰到蛋
        egg = {     //在新位置刷新蛋
            x: parseInt(Math.random() * 20),
            y: parseInt(Math.random() * 20)
        }
        snake.push(snake[-1]) //在蛇尾增加新的一节（复制当前最后一节的坐标）
        snake.push(snake[-1])
        snake.push(snake[-1])
    }
    snake.pop() //删除最后一节

    draw()
}
document.onkeydown = function (evt) { //判断按键事件，根据按键调整蛇头的移动方向，同时过滤与移动方向相反的按键，防止原地调头自杀
    switch (evt.key) {
        case "ArrowUp":
            if (head.y != 1) {
                head.y = -1
                head.x = 0
            }
            break
        case "ArrowRight":
            if (head.x != -1) {
                head.y = 0
                head.x = 1
            }
            break
        case "ArrowDown":
            if (head.y != -1) {
                head.y = 1
                head.x = 0
            }
            break
        case "ArrowLeft":
            if (head.x != 1) {
                head.y = 0
                head.x = -1
            }
            break
    }
}
newgame()
setInterval(move, 200) //每隔200m刷新一下游戏画面通过更改刷新频率可以提高速度，也可以把刷新速度和蛇的长度绑定，做到尾巴越长移动越快的效果