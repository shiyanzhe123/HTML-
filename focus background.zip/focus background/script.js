var cir = document.getElementById("cir")
document.onmousemove = function (evt) {
    var evt = event || window.Event
    var x = evt.clientX
    var y = evt.clientY
    cir.style.setProperty('--x', x + "px")
    cir.style.setProperty('--y', y + "px")
}