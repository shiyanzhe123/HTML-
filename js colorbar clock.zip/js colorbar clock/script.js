var monbox = document.getElementById("month")
var daybox = document.getElementById("day")
var hourbox = document.getElementById("hour")
var minbox = document.getElementById("min")
var secbox = document.getElementById("sec")
var yeardiv = document.getElementById("year")
var count = 0
function clock() {
    var d = new Date()
    var mon = d.getMonth()
    var day = d.getDate()
    var hour = d.getHours()
    var min = d.getMinutes()
    var sec = d.getSeconds()
    var year = d.getFullYear()

    monbox.style.setProperty('--s', String(mon / 12 * 100) + '%') //生成填充背景颜色的比例
    monbox.setAttribute('datatext', ("0" + (mon + 1)).slice(-2)) //生成时间日期的具体文字，个位的数字在前面补0

    var allday = new Date(year, mon + 1, 0).getDate() //计算当前月份有多少天（28，29，30，31）
    daybox.style.setProperty('--s', String(day / allday * 100) + '%')
    daybox.setAttribute('datatext', ("0" + (day)).slice(-2))

    hourbox.style.setProperty('--s', String(hour / 24 * 100) + '%')
    hourbox.setAttribute('datatext', ("0" + (hour)).slice(-2))

    minbox.style.setProperty('--s', String(min / 60 * 100) + '%')
    minbox.setAttribute('datatext', ("0" + (min)).slice(-2))

    secbox.style.setProperty('--s', String(sec / 60 * 100) + '%')
    secbox.setAttribute('datatext', ("0" + (sec)).slice(-2))

    yeardiv.innerText = year // 计算年份数字
}
setInterval(clock, 100)