var all = document.getElementsByClassName("colorbox").length //获取所有colorbox类的数量
var str = ""
for (var i = 0; i < all; i++) {  //!!!视频中的错误导致只画出来7个色块，因为i的初始值设成了1
    m = document.getElementsByClassName("colorbox")[i] //遍历所有的colorbox类
    str = ""
    for (var c = 0; c < 3; c++) { //分别生成RGB值
        str += ("0" + parseInt(Math.random() * 255).toString(16)).slice(-2) //将生成的颜色值转为2位的16进制值
    }
    m.style.background = "#" + str //拼接为颜色值并设置背景颜色
    m.innerHTML = "#" + str  //将色值文本写入对应的色块
}
function pickcolor(val) {  //复制色值函数
    for (var i = 0; i < all; i++) {   //遍历所有的colorbox类并重置属性设置
        n = document.getElementsByClassName("colorbox")[i]
        n.style.color = "white"
        n.style.boxShadow = "none"
        n.style.textShadow = "0 0 1px black,0 0 2px black"
    }
    m = document.getElementsByClassName("colorbox")[val] //获取当前色块
    m.style.color = "black" //调整样式
    m.style.boxShadow = "inset 0 0 2vw white"
    m.style.textShadow = "0 0 1px white,0 0 2px white"
    clip = document.createElement("input") //新建input元素
    clip.setAttribute("value", rgb2hex(m.style.background))  //将转为16进制的颜色值设为input的值
    document.body.appendChild(clip)  //将元素添加为body的子元素
    clip.select()   //选中input的内容
    document.execCommand("copy") //执行复制命令将值写入剪贴板
    document.body.removeChild(clip) //将元素移除
}
// #f0d31b #07a5f3 
function rgb2hex(val) {  //将rgb字符串改为16进制颜色值
    var hexstr = String(val).slice(4, -1) //去掉'rgb(' 及 ')'
    var hexarr = hexstr.split(",") //将剩下的文本根据','分割为数组
    var hex = ""
    for (var i = 0; i < 3; i++) {  //遍历数组，将文本转为数字，并转为2位16进制
        hex += ("0" + parseInt(hexarr[i]).toString(16)).slice(-2)
    }
    return "#" + hex    //返回带有'#'的色值
}