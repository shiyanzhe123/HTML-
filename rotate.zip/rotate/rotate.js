const body = document.querySelector("body");
const menuContainer = document.querySelector(".menu-container");
const menu = document.querySelector(".menu");
const menuSize = 300;
const menuTopMax = window.innerHeight - menuSize;
const menuLeftMax = window.innerWidth - menuSize;
let menuVisable = false;

document.oncontextmenu = e => e.preventDefault();

body.onmousedown = e => {
    if (e.button == 2) {
        let top = e.clientY - menuSize / 2;
        let left = e.clientX - menuSize / 2;
        if (top < 0) top = 0;
        else if (top > menuTopMax) top = menuTopMax;
        if (left < 0) left = 0;
        else if (left > menuLeftMax) left = menuLeftMax;
        menuContainer.style.top = top + "px";
        menuContainer.style.left = left + "px";
        if (menuVisable) {
            menu.classList.remove("menu-open");
        }
        else {
            menu.classList.add("menu-open");
        }
        menuVisable = !menuVisable;
    }
}