var canvas = document.getElementById("canvas")
var ctx = canvas.getContext("2d")
var img = new Image() //新建图片对象
img.src = "yellowface.jpg" //载入图片
canvas.width = img.width * 3 //设置画布尺寸为图片的三倍
canvas.height = img.height * 3
var pixals = [] //新建数组用于存放图片信息
img.onload = function () { //载入图片后执行
    ctx.drawImage(img, 0, 0) //画布上画上图片
    var imageData = ctx.getImageData(0, 0, img.width, img.height) //将图片信息存入数组
    ctx.clearRect(0, 0, canvas.width, canvas.height) //清空画布
    for (var i = 0; i < imageData.data.length / 4; i++) { //遍历数组，四个元素为一组
        pixals.push({ //插入图片数组
            lx: i % img.width, //取余为X坐标
            ly: parseInt(i / img.width), //整除为y坐标
            color: "rgb(" + imageData.data[i * 4] + "," + imageData.data[i * 4 + 1] + "," + imageData.data[i * 4 + 2] + ")", //取前三个值生成rgb颜色字符串
            vx: parseInt(Math.random() * img.width), //在画布范围内随机生成坐标
            vy: parseInt(Math.random() * img.height)
        })
    }
    setInterval(draw, 1) //每毫秒调用一次绘图函数
}
function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height) //清空画布
    
        for (var i = 0; i < pixals.length; i++) { //遍历数组
            pixal = pixals[i]
            ctx.fillStyle = pixal.color //设置填充颜色
            ctx.fillRect(pixal.vx * 3, pixal.vy * 3, 2, 2) //根据随机坐标绘制像素点
            pixal.vx -= (pixal.vx - pixal.lx) / 10 //每次向原始坐标运动1/10,实际效果为像素点移动速度越来越慢,直到归位
            pixal.vy -= (pixal.vy - pixal.ly) / 10
            
        }
    

}
