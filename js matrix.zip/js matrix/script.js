var canvas=document.getElementById("canvas")
var context=canvas.getContext("2d")
var w=window.innerWidth
var h=window.innerHeight
canvas.width=w
canvas.height=h
var strl=20 //垂直字符串长度
var count = 20 //改变字符前移动的距离
var wx=parseInt(w/20)+1 //字符串出现的位置
var hy=parseInt(h/20)+1
var num=100 //字符串数量
var letters=[]
var text="ヴアグバネュロヨヱヴヴアグバネュロヨヱ" //字符串取值

for(var i=0;i<num;i++){//初始化字符串
    letters.push({
        str:[],
        x:parseInt(Math.random()*wx)*20, //字符串随机出现的位置
        y:parseInt(Math.random()*hy)*20
    })
}

function draw(){ //绘制字符串
    context.clearRect(0,0,w,h) //清屏
    for(var i=0;i<num;i++){
        var letter=letters[i]
        if(count==20){  //判断是否需要重新生成字符串内容
            letter.str=[]
            for(var k=0;k<strl;k++){
                letter.str.push(text[parseInt(Math.random()*text.length)]) //随机生成字符串内容
            }    
        }
        for(var j=0;j<strl;j++){
            if(j==0){ //第一个字符为白色
                context.fillStyle="white"
            }
            else{ //后面的字符按照顺序从绿色过渡到无色
                context.fillStyle="rgba(0,255,0,"+String(1-j/strl)+")"
            }
            context.font="20px Arial" //字符尺寸与count一致，确保移动1个字符的高度后重新刷新字符串
            context.fillText(letter.str[j],letter.x,letter.y-20*j) //垂直绘制字符串
        }
    }
    move()
}
function move(){
    count+=1 // 计数器增加
    if(count>20){   //超过一个字符高度时则重置计数器
        count=0
    }
    for(var i=0;i<num;i++){
        var letter=letters[i]
        letter.y+=1 //字符串向下移动一个像素
        if(letter.y-20*strl>h){ //当完整的字符串移出屏幕范围后，在随机位置重绘字符串
            letters[i]={
                str:letter.str,
                x:parseInt(Math.random() * wx) *20,
                y:parseInt(Math.random() * hy) *20
            }
        }
    }
    
}
draw()
setInterval(draw,1)