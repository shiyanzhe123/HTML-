var canvas = document.getElementById("canvas")
var context = canvas.getContext("2d")
var w = window.innerWidth
var h = window.innerHeight
canvas.width = w
canvas.height = h
var countx = parseInt(w / 30) + 1
var county = parseInt(h / 30) + 1
context.clearRect(0, 0, w, h)
//简单正方形格子
// for (var i = 0; i < countx; i++) {
//     for (var j = 0; j < county; j++) {
//         context.fillStyle = "#333"
//         context.fillRect(i * 30, j * 30, 28, 28)
//     }
// }
for (var i = 0; i < w / 60 + 1; i++) { //制作六边形效果，计算出每行的六边形数量
    for (var j = 0; j < h / Math.sqrt(0.75 * 22 * 22) + 1; j++) { //计算出每列六边形数量，由于交错排列，需要根据三角函数调整数量
        startx = i * 66  //横坐标间距
        starty = j * Math.sqrt(0.75 * 22 * 22) //垂直间距
        if (j % 2 == 0) {  //隔行位移
            startx = i * 66 + 33 //根据半径偏移
        }
        // context.fillStyle = "#333" //纯色效果
        context.fillStyle = "rgba(51,51,51," + Math.random() + ")" //随机半透明效果
        context.strokeStyle = "#333" //画线的颜色，可以参考上一行修改
        context.beginPath() //开始路径
        context.moveTo(startx - 10, starty + Math.sqrt(0.75 * 20 * 20)) //画笔移动至左上方的A点
        context.lineTo(startx + 10, starty + Math.sqrt(0.75 * 20 * 20)) //根据坐标画线
        context.lineTo(startx + 20, starty)
        context.lineTo(startx + 10, starty - Math.sqrt(0.75 * 20 * 20))
        context.lineTo(startx - 10, starty - Math.sqrt(0.75 * 20 * 20))
        context.lineTo(startx - 20, starty)
        context.closePath()  //闭合路径
        context.stroke()    //画线
        context.fill()  //填充

    }

}

var light = document.getElementById("light") //通过跟踪鼠标位置调整背景光的位置
document.onmousemove = function (event) {
    var evt = event || window.Event
    var x = evt.clientX - 50
    var y = evt.clientY - 50
    light.style.left = x + "px"
    light.style.top = y + "px"
}