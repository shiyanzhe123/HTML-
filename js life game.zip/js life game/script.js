var canvas = document.getElementById("canvas")
var context = canvas.getContext("2d")
var map = { //自定义地图尺寸
    x: 200,
    y: 100
}
var speed = 100 //刷新速度
canvas.width = map.x * 8 
canvas.height = map.y * 8

var lives = []
for (var i = 0; i < map.x * map.y; i++) { //默认无生命
    lives.push("white")
}
function draw() {
    context.clearRect(0, 0, canvas.width, canvas.height)
    for (var i = 0; i < lives.length; i++) {
        life = lives[i]
        context.fillStyle = life
        context.fillRect((i % map.x) * 8, parseInt(i / map.x) * 8, 7, 7) //根据地图尺寸画上格子
    }
    golive()
}
function seed() { //随机生成生命
    var seeds = 1500 //初始生命数量
    for (var i = 0; i < seeds; i++) {
        lives[parseInt(Math.random() * lives.length)] = "black"
    }
}
function golive() {
    var next = []
    var count = 0
    // 周边生命索引速查
    // -map.x-1,-map.x,-map.x+1
    //  -1,   0   ,1 
    //  map.x-1,map.x,map.x+1

    for (i = 0; i < map.x * map.y; i++) {
        count = 0
        if (i == 0) { //左上角
            checkbox = [1, map.x, map.x + 1]
        }
        else if (i == map.x - 1) {//右上角
            checkbox = [-1, map.x - 1, map.x]
        }
        else if (i == map.x * map.y - map.x) { //左下角
            checkbox = [-map.x, -map.x + 1, 1]
        }
        else if (i == map.x * map.y - 1) { //右下角
            checkbox = [-map.x - 1, -map.x, -1]
        }
        else if (i > 0 && i < map.x - 1) { //上边
            checkbox = [-1, 1, map.x - 1, map.x, map.x + 1]
        }
        else if (i > map.x - 1 && parseInt(i % map.x) == map.x - 1 && i < map.x * map.y - 1) { //右边
            checkbox = [-map.x - 1, -map.x, -1, map.x - 1, map.x]
        }
        else if (i > map.x * map.y - map.x && i < map.x * map.y) { //下边
            checkbox = [-map.x - 1, -map.x, -map.x + 1, -1, 1]
        }
        else if (i > 0 && i < map.x * map.y - map.x && parseInt(i % map.x) == 0) {//左边框            
            checkbox = [-map.x, -map.x + 1, 1, map.x, map.x + 1]
        }
        else { //中间部分
            checkbox = [-map.x - 1, -map.x, -map.x + 1,- 1, 1,map.x - 1, map.x, map.x + 1]
        }
        checkbox.forEach(function(val){ //根据checkbox的值检查周边生命数量
            if(lives[i+val]=="black"){
                count+=1
            }
            
        })
        
        if(count>=3 && count<=5){ //划定生命生成条件
            next[i]="black"
        }
        else{
            next[i]="white"
        }
    }
    lives = next //将结果赋值给生命数组
}
seed()
setInterval(draw,speed)