let canvas = document.getElementById("canvas")
canvas.width = window.innerWidth
canvas.height = window.innerHeight
let ctx = canvas.getContext("2d")
let balls = []
let drops = []
let gravity = 0.1
ctx.fillStyle = "white"
class ball {
    constructor() {
        this.x = Math.random() * canvas.width
        this.y = Math.random() * canvas.height / 5
        this.radius = Math.random() * 50 + 30
        this.speed = 1 - this.radius / 90
        this.vx = (Math.random() - 0.5) * this.speed * 5
        this.vy = (Math.random() - 0.5) * this.speed * 5
    }
    update() {
        this.x += this.vx
        this.y += this.vy
    }
    draw() {
        ctx.beginPath()
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2, 0)
        ctx.fill()
    }
}
class drop {
    constructor() {
        this.x = Math.random() * canvas.width
        this.y = Math.random() * canvas.height / 5
        this.r = Math.random() * 5 + 5
        this.vy = Math.random() * 0.05
    }
    update() {
        this.y += this.vy
        this.vy += gravity
    }
    draw() {
        ctx.beginPath()
        ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2, 0)
        ctx.fill()
    }
}

function init() {
    for (var i = 0; i < 200; i++) {
        balls.push(new ball())
    }
}
init()

function animation() {
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    if (drops.length < 20) {
        drops.push(new drop())
    }
    for (var i in drops) {
        let d = drops[i]
        d.update()
        d.draw()
        if (d.y > canvas.height + d.r) {
            drops.splice(i, 1)
        }
    }
    for (var i in balls) {
        let b = balls[i]
        b.update()
        b.draw()
        if (b.x < b.radius || b.x > canvas.width - b.radius) {
            b.vx *= -1
        }
        if (b.y < b.radius || b.y > canvas.height / 5 - b.radius) {
            b.vy *= -1
        }
    }
}
setInterval(animation, 1000 / 60)