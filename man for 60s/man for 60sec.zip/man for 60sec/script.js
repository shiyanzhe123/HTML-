var canvas = document.getElementById("canvas")
var ctx = canvas.getContext("2d")
var cRect = canvas.getBoundingClientRect()
var pixals = []
var run = true
canvas.width = 600
canvas.height = 400
var mouse = {
    x: 0,
    y: 0
}
window.addEventListener("mousemove", function (evt) {
    var x = evt.clientX - cRect.left
    var y = evt.clientY - cRect.top
    if (x < 600 && x > 0 && y < 400 && y > 0) {
        mouse.x = x
        mouse.y = y
    }

})
function newpixal() {
    pixals.push({
        sx: 599,
        sy: 399,
        vx: (0.5 - Math.random()) * 2,
        vy: (0.5 - Math.random()) * 2
    })
}
function draw() {
    if (run) {
        ctx.clearRect(0, 0, canvas.width, canvas.height)
        ctx.font = "20px sans-serif"
        ctx.fillStyle = "#1e90ff"
        ctx.fillText(pixals.length, 5, 20)
        ctx.fillStyle = "red"
        ctx.beginPath()
        ctx.arc(mouse.x, mouse.y, 5, 0, 2 * Math.PI)
        ctx.fill()
        ctx.fillStyle = "white"
        for (var i = 0; i < pixals.length; i++) {
            pixal = pixals[i]
            ctx.beginPath()
            ctx.arc(pixal.sx, pixal.sy, 2, 0, 2 * Math.PI)
            ctx.fill()
            pixal.sx += pixal.vx
            pixal.sy += pixal.vy
            if (pixal.sx < 0 || pixal.sx > 600) {
                pixal.vx = -pixal.vx
            }
            if (pixal.sy < 0 || pixal.sy > 400) {
                pixal.vy = -pixal.vy
            }
            if (Math.abs(pixal.sx - mouse.x) < 7 && Math.abs(pixal.sy - mouse.y) < 7) {
                run = false
                var r = confirm("游戏结束，您一共坚持了" + pixals.length + "秒,\n 按[确定]重新开始。")
                if (r) {
                    pixals = []
                    run = true

                }
            }
        }

    }
}
newpixal()
setInterval(newpixal, 1000)
setInterval(draw, 1)