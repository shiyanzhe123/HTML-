var canvas = document.getElementById("canvas")
var ctx = canvas.getContext("2d")
canvas.width = 960 //设置画布尺寸
canvas.height = 600
ctx.font = "30px Arial" //设置文字尺寸及字体
ctx.fillStyle = "white" //设置颜色（颜色随意，反正只需要一个透明度的数据）
ctx.fillText("BILIBILI", 0, 30) //在画布中写入文字，注意文字原点坐标是左下角，为了显示完整要留出文字的高度
var pix = ctx.getImageData(0, 0, 120, 30) //读取文字写入的部分写入对象
var textpix = [] //定义数组保存像素信息
for (var i = 0; i < pix.data.length / 4; i++) { //因为每四个元素为一个像素，所以取1/4数组长度
    textpix.push({
        tx:i % 120, //像素x坐标
        ty:parseInt(i / 120), //像素y坐标
        alpha:pix.data[i * 4 + 3], //像素透明度
        rx:parseInt(Math.random() * canvas.width/8 -7.5), //随机坐标,分布于整个画布范围
        ry:parseInt(Math.random() * canvas.height/8 -20 ),
    })
}
var move = []
for (var i = 0; i < textpix.length; i++) { //遍历文字像素数组
    tpix = textpix[i]
    move.push([
        (tpix.rx - tpix.tx) / 2000, //根据随机坐标与原始坐标的距离差计算位移距离
        (tpix.ry - tpix.ty) / 2000
    ])
}
var count = 0 //计数器清零
function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height) //清屏
    for (var i = 0; i < textpix.length; i++) { //遍历文字像素数组
        tpix = textpix[i] //单个像素
        ctx.fillStyle = "rgba(30, 144, 255," + tpix.alpha + ")" //根据透明度设置填充颜色
        ctx.fillRect(tpix.rx * 8+60, tpix.ry * 8+160, 6, 6) //根据随机坐标点绘制像素，扩大8倍，矩形之间2像素留空，调整位移为画布中间
        if (count < 2000) { //位移计数，2000次后停止位移
            tpix.rx -= move[i][0] //将随机坐标点向原始坐标移动，每次移动距离为1/2000
            tpix.ry -= move[i][1]  
        }
    }
    count++ //累加计数器
}
setInterval(draw, 1) //走你~